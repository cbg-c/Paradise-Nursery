"use client"

import Image from "next/image"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardFooter } from "@/components/ui/card"
import type { Plant } from "@/lib/plants-data"

interface PlantCardProps {
  plant: Plant
  onAddToCart: (plant: Plant) => void
}

export function PlantCard({ plant, onAddToCart }: PlantCardProps) {
  return (
    <Card className="overflow-hidden hover:shadow-lg transition-shadow duration-300">
      <div className="aspect-square relative overflow-hidden">
        <Image
          src={plant.image || "/placeholder.svg"}
          alt={plant.name}
          fill
          className="object-cover hover:scale-105 transition-transform duration-300"
        />
      </div>
      <CardContent className="p-4">
        <h3 className="font-semibold text-lg text-card-foreground mb-2">{plant.name}</h3>
        <p className="text-muted-foreground text-sm mb-3 line-clamp-3">{plant.description}</p>
        <div className="flex items-center justify-between">
          <span className="text-2xl font-bold text-primary">${plant.price}</span>
        </div>
      </CardContent>
      <CardFooter className="p-4 pt-0">
        <Button onClick={() => onAddToCart(plant)} className="w-full" size="sm">
          Add to Cart
        </Button>
      </CardFooter>
    </Card>
  )
}
