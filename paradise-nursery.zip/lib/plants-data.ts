export interface Plant {
  id: string
  name: string
  description: string
  price: number
  image: string
  category: "aromatic" | "medicinal"
}

export const plantsData: Plant[] = [
  // Aromatic Plants
  {
    id: "lavender",
    name: "Lavender",
    description:
      "A fragrant herb known for its calming properties and beautiful purple flowers. Perfect for relaxation and aromatherapy.",
    price: 24.99,
    image: "/lavender-plant-in-pot.jpg",
    category: "aromatic",
  },
  {
    id: "rosemary",
    name: "Rosemary",
    description:
      "An evergreen herb with needle-like leaves and a woody aroma. Excellent for cooking and natural air freshening.",
    price: 18.99,
    image: "/rosemary-herb-plant-in-terracotta-pot.jpg",
    category: "aromatic",
  },
  {
    id: "mint",
    name: "Fresh Mint",
    description:
      "A refreshing herb with bright green leaves. Perfect for teas, cocktails, and adding fresh fragrance to your home.",
    price: 15.99,
    image: "/fresh-mint-plant-in-white-pot.jpg",
    category: "aromatic",
  },
  {
    id: "basil",
    name: "Sweet Basil",
    description:
      "A classic culinary herb with a sweet, peppery aroma. Essential for Italian cooking and natural pest deterrent.",
    price: 16.99,
    image: "/sweet-basil-plant-with-green-leaves.jpg",
    category: "aromatic",
  },
  {
    id: "eucalyptus",
    name: "Eucalyptus",
    description:
      "An aromatic plant with silvery-green leaves. Known for its refreshing scent and air-purifying qualities.",
    price: 32.99,
    image: "/eucalyptus-plant-with-silver-leaves.jpg",
    category: "aromatic",
  },
  {
    id: "lemongrass",
    name: "Lemongrass",
    description: "A tropical grass with a citrusy fragrance. Great for teas, cooking, and natural mosquito repellent.",
    price: 19.99,
    image: "/lemongrass-plant-in-decorative-pot.jpg",
    category: "aromatic",
  },

  // Medicinal Plants
  {
    id: "aloe-vera",
    name: "Aloe Vera",
    description:
      "A succulent plant known for its healing gel. Perfect for treating burns, cuts, and skin irritations naturally.",
    price: 22.99,
    image: "/aloe-vera-succulent-plant-in-pot.jpg",
    category: "medicinal",
  },
  {
    id: "chamomile",
    name: "Chamomile",
    description:
      "A gentle herb with daisy-like flowers. Renowned for its calming effects and use in herbal teas for relaxation.",
    price: 17.99,
    image: "/chamomile-plant-with-white-flowers.jpg",
    category: "medicinal",
  },
  {
    id: "echinacea",
    name: "Echinacea",
    description:
      "A purple flowering plant known for immune system support. Beautiful blooms with powerful health benefits.",
    price: 26.99,
    image: "/echinacea-purple-coneflower-plant.jpg",
    category: "medicinal",
  },
  {
    id: "ginseng",
    name: "Ginseng",
    description:
      "A prized medicinal root known for boosting energy and supporting overall wellness. A true superfood plant.",
    price: 45.99,
    image: "/ginseng-plant-with-distinctive-leaves.jpg",
    category: "medicinal",
  },
  {
    id: "turmeric",
    name: "Turmeric",
    description:
      "A golden root with powerful anti-inflammatory properties. Fresh turmeric adds both flavor and health benefits.",
    price: 28.99,
    image: "/turmeric-plant-with-broad-green-leaves.jpg",
    category: "medicinal",
  },
  {
    id: "calendula",
    name: "Calendula",
    description: "Bright orange flowers with healing properties. Excellent for skin care and natural wound healing.",
    price: 20.99,
    image: "/calendula-orange-marigold-flowers-in-pot.jpg",
    category: "medicinal",
  },
]

export const getPlantsByCategory = (category: "aromatic" | "medicinal") => {
  return plantsData.filter((plant) => plant.category === category)
}

export const getPlantById = (id: string) => {
  return plantsData.find((plant) => plant.id === id)
}
