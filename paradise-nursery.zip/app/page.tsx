import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Navigation } from "@/components/navigation"
import { Leaf, Heart, Shield, Truck } from "lucide-react"

export default function HomePage() {
  return (
    <div className="min-h-screen bg-background">
      <Navigation />

      {/* Hero Section */}
      <section className="relative bg-gradient-to-b from-muted to-background py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <div className="max-w-3xl mx-auto">
            <h1 className="text-4xl md:text-6xl font-bold text-foreground mb-6 text-balance">
              Welcome to Paradise Nursery
            </h1>
            <p className="text-xl text-muted-foreground mb-8 text-pretty">
              Discover the perfect plants to transform your home into a green paradise. From aromatic herbs to medicinal
              wonders, we have everything you need to create your indoor oasis.
            </p>
            <Link href="/products">
              <Button size="lg" className="text-lg px-8 py-3">
                Shop Plants Now
              </Button>
            </Link>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-16 bg-background">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-foreground mb-4">Why Choose Paradise Nursery?</h2>
            <p className="text-muted-foreground max-w-2xl mx-auto">
              We're passionate about bringing nature into your home with the highest quality plants and expert care
              guidance.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            <Card className="text-center p-6">
              <CardContent className="pt-6">
                <Leaf className="h-12 w-12 text-primary mx-auto mb-4" />
                <h3 className="font-semibold text-lg mb-2">Premium Quality</h3>
                <p className="text-muted-foreground text-sm">Hand-selected plants from trusted growers</p>
              </CardContent>
            </Card>

            <Card className="text-center p-6">
              <CardContent className="pt-6">
                <Heart className="h-12 w-12 text-accent mx-auto mb-4" />
                <h3 className="font-semibold text-lg mb-2">Expert Care</h3>
                <p className="text-muted-foreground text-sm">Detailed care instructions with every plant</p>
              </CardContent>
            </Card>

            <Card className="text-center p-6">
              <CardContent className="pt-6">
                <Shield className="h-12 w-12 text-primary mx-auto mb-4" />
                <h3 className="font-semibold text-lg mb-2">Health Guarantee</h3>
                <p className="text-muted-foreground text-sm">30-day health guarantee on all plants</p>
              </CardContent>
            </Card>

            <Card className="text-center p-6">
              <CardContent className="pt-6">
                <Truck className="h-12 w-12 text-accent mx-auto mb-4" />
                <h3 className="font-semibold text-lg mb-2">Safe Delivery</h3>
                <p className="text-muted-foreground text-sm">Secure packaging and fast shipping</p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Call to Action */}
      <section className="py-16 bg-muted">
        <div className="max-w-4xl mx-auto text-center px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl font-bold text-foreground mb-4">Ready to Start Your Plant Journey?</h2>
          <p className="text-muted-foreground mb-8 text-lg">
            Browse our collection of aromatic and medicinal plants to find the perfect additions to your home.
          </p>
          <Link href="/products">
            <Button size="lg" className="text-lg px-8 py-3">
              Explore Our Plants
            </Button>
          </Link>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-primary text-primary-foreground py-8">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <div className="flex items-center justify-center space-x-2 mb-4">
            <Leaf className="h-6 w-6" />
            <span className="font-bold text-lg">Paradise Nursery</span>
          </div>
          <p className="text-primary-foreground/80">Bringing nature home, one plant at a time.</p>
        </div>
      </footer>
    </div>
  )
}
