"use client"
import { Navigation } from "@/components/navigation"
import { PlantCard } from "@/components/plant-card"
import { getPlantsByCategory, type Plant } from "@/lib/plants-data"
import { Button } from "@/components/ui/button"
import { useToast } from "@/hooks/use-toast"
import { useCart } from "@/lib/cart-context"

export default function ProductsPage() {
  const { dispatch } = useCart()
  const { toast } = useToast()

  const aromaticPlants = getPlantsByCategory("aromatic")
  const medicinalPlants = getPlantsByCategory("medicinal")

  const handleAddToCart = (plant: Plant) => {
    dispatch({ type: "ADD_ITEM", payload: plant })
    toast({
      title: "Added to cart!",
      description: `${plant.name} has been added to your cart.`,
    })
  }

  return (
    <div className="min-h-screen bg-background">
      <Navigation />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header */}
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-foreground mb-4">Our Plant Collection</h1>
          <p className="text-muted-foreground max-w-2xl mx-auto text-lg">
            Discover our carefully curated selection of aromatic and medicinal plants, each chosen for their beauty,
            benefits, and ease of care.
          </p>
        </div>

        {/* Aromatic Plants Section */}
        <section className="mb-16">
          <div className="flex items-center justify-between mb-8">
            <div>
              <h2 className="text-3xl font-bold text-foreground mb-2">Aromatic Plants</h2>
              <p className="text-muted-foreground">Fill your home with natural fragrances and fresh scents</p>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {aromaticPlants.map((plant) => (
              <PlantCard key={plant.id} plant={plant} onAddToCart={handleAddToCart} />
            ))}
          </div>
        </section>

        {/* Medicinal Plants Section */}
        <section className="mb-16">
          <div className="flex items-center justify-between mb-8">
            <div>
              <h2 className="text-3xl font-bold text-foreground mb-2">Medicinal Plants</h2>
              <p className="text-muted-foreground">Natural healing and wellness plants for your health journey</p>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {medicinalPlants.map((plant) => (
              <PlantCard key={plant.id} plant={plant} onAddToCart={handleAddToCart} />
            ))}
          </div>
        </section>

        {/* Call to Action */}
        <section className="text-center py-12 bg-muted rounded-lg">
          <h3 className="text-2xl font-bold text-foreground mb-4">Can't Find What You're Looking For?</h3>
          <p className="text-muted-foreground mb-6 max-w-md mx-auto">
            Contact our plant experts for personalized recommendations and special orders.
          </p>
          <Button variant="outline" size="lg">
            Contact Us
          </Button>
        </section>
      </div>
    </div>
  )
}
